@extends('layout')

@section('title', 'Statistiques Avancées - Zebus Space')

@section('content')
<div class="max-w-[1400px] mx-auto px-8 py-8">
    <div class="mb-8 flex items-center justify-between">
        <div>
            <h1 class="text-4xl mb-2">Statistiques Avancées</h1>
            <p class="text-gray-600">Analyse complète des performances</p>
        </div>
        <div class="flex gap-3">
            <button class="bg-[#4ADE80] text-white px-6 py-3 rounded-lg hover:bg-[#3ABE70] transition-colors flex items-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
                </svg>
                Exporter Excel
            </button>
            <button class="bg-[#EF4444] text-white px-6 py-3 rounded-lg hover:bg-[#DC2626] transition-colors flex items-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
                </svg>
                Exporter PDF
            </button>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-4 gap-6 mb-8">
        <div class="bg-[#F4E04D] rounded-2xl p-6">
            <svg class="w-10 h-10 mb-4 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/>
            </svg>
            <div class="text-4xl mb-2">2.8M</div>
            <div class="text-sm text-gray-700">Chiffre d'Affaires</div>
        </div>
        <div class="bg-black rounded-2xl p-6 text-white">
            <svg class="w-10 h-10 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/>
            </svg>
            <div class="text-4xl mb-2">1,247</div>
            <div class="text-sm text-gray-300">Total Commandes</div>
        </div>
        <div class="bg-white rounded-2xl p-6 border border-gray-200">
            <svg class="w-10 h-10 mb-4 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
            </svg>
            <div class="text-4xl mb-2">342</div>
            <div class="text-sm text-gray-600">Clients Actifs</div>
        </div>
        <div class="bg-[#F4E04D] rounded-2xl p-6">
            <svg class="w-10 h-10 mb-4 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/>
            </svg>
            <div class="text-4xl mb-2">4.7</div>
            <div class="text-sm text-gray-700">Satisfaction</div>
        </div>
    </div>

    <div class="grid grid-cols-2 gap-6 mb-8">
        <!-- Évolution des Ventes -->
        <div class="bg-white rounded-2xl p-6">
            <h3 class="text-xl mb-6">Évolution des Ventes</h3>
            <canvas id="salesChart" width="400" height="300"></canvas>
        </div>

        <!-- Répartition par Catégorie -->
        <div class="bg-white rounded-2xl p-6">
            <h3 class="text-xl mb-6">Répartition par Catégorie</h3>
            <canvas id="categoryChart" width="400" height="300"></canvas>
        </div>
    </div>

    <div class="grid grid-cols-2 gap-6 mb-8">
        <!-- Programme de Fidélité -->
        <div class="bg-white rounded-2xl p-6">
            <h3 class="text-xl mb-6">Programme de Fidélité</h3>
            <canvas id="loyaltyChart" width="400" height="300"></canvas>
        </div>

        <!-- Système de Parrainage -->
        <div class="bg-white rounded-2xl p-6">
            <h3 class="text-xl mb-6">Système de Parrainage</h3>
            <canvas id="referralChart" width="400" height="300"></canvas>
        </div>
    </div>

    <!-- Performance Détaillée par Période -->
    <div class="bg-white rounded-2xl overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
            <h3 class="text-xl">Performance Détaillée par Période</h3>
        </div>
        
        <!-- Table Header -->
        <div class="bg-[#F4E04D] px-6 py-4 grid grid-cols-6 gap-4">
            <div>Période</div>
            <div>Commandes</div>
            <div>Revenus</div>
            <div>Clients</div>
            <div>Panier moyen</div>
            <div>Evolution</div>
        </div>

        <!-- Table Body -->
        <div class="divide-y divide-gray-100">
            @foreach($performanceData ?? [] as $row)
            <div class="px-6 py-5 grid grid-cols-6 gap-4 items-center hover:bg-gray-50 transition-colors">
                <div>{{ $row['period'] }}</div>
                <div>{{ $row['commandes'] }}</div>
                <div>{{ $row['revenus'] }}</div>
                <div>{{ $row['clients'] }}</div>
                <div>{{ $row['panierMoyen'] }}</div>
                <div class="{{ $row['evolutionColor'] }}">{{ $row['evolution'] }}</div>
            </div>
            @endforeach
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
// Graphique Évolution des Ventes
const salesCtx = document.getElementById('salesChart').getContext('2d');
new Chart(salesCtx, {
    type: 'line',
    data: {
        labels: ['Jan', 'Fev', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Aou', 'Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [{
            label: 'Ventes 2025 (Millions FCFA)',
            data: [4, 3, 5, 7, 9, 8, 10, 9, 11, 10, 12, 14],
            borderColor: '#F4E04D',
            borderWidth: 2,
            fill: false,
            tension: 0.4
        }, {
            label: 'Ventes 2024 (Millions FCFA)',
            data: [2, 3, 4, 5, 6, 7, 8, 7, 8, 9, 10, 11],
            borderColor: '#000000',
            borderWidth: 2,
            fill: false,
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true
    }
});

// Graphique Répartition par Catégorie
const categoryCtx = document.getElementById('categoryChart').getContext('2d');
new Chart(categoryCtx, {
    type: 'doughnut',
    data: {
        labels: ['Plats Principaux', 'Grillades', 'Boissons', 'Desserts'],
        datasets: [{
            data: [45, 25, 20, 10],
            backgroundColor: ['#F4E04D', '#D4AF37', '#000000', '#F4E04D']
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true
    }
});

// Graphique Programme de Fidélité
const loyaltyCtx = document.getElementById('loyaltyChart').getContext('2d');
new Chart(loyaltyCtx, {
    type: 'bar',
    data: {
        labels: ['Points Gagnes', 'Point utilises', 'Cadeaux echanges', 'Nouveaux membres'],
        datasets: [{
            data: [100, 80, 35, 60],
            backgroundColor: ['#F4E04D', '#000000', '#EF4444', '#4ADE80']
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                display: false
            }
        }
    }
});

// Graphique Système de Parrainage
const referralCtx = document.getElementById('referralChart').getContext('2d');
new Chart(referralCtx, {
    type: 'line',
    data: {
        labels: ['Sem 1', 'Sem 2', 'Sem 3', 'Sem 4', 'Sem 5', 'Sem 6', 'Sem 7', 'Sem 8'],
        datasets: [{
            label: 'Nouveaux Filleuls',
            data: [12, 18, 25, 30, 35, 40, 42, 45],
            borderColor: '#F4E04D',
            borderWidth: 2,
            fill: false,
            tension: 0.4
        }, {
            label: 'Commissions Payées',
            data: [8, 12, 18, 22, 28, 32, 35, 38],
            borderColor: '#000000',
            borderWidth: 2,
            fill: false,
            tension: 0.4
        }, {
            label: "Commissions d'Attente",
            data: [4, 6, 7, 8, 7, 8, 7, 7],
            borderColor: '#6B7FFF',
            borderWidth: 2,
            fill: false,
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true
    }
});
</script>
@endpush
