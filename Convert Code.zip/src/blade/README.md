# Fichiers Blade - Plateforme Gérant Zebus Space

## Structure des fichiers

```
blade/
├── layout.blade.php           # Layout principal
├── partials/
│   ├── header.blade.php       # Header avec navigation
│   └── footer.blade.php       # Footer
├── dashboard.blade.php        # Page Dashboard
├── employe.blade.php          # Page Gestion Employés
├── statistiques.blade.php     # Page Statistiques
└── reclamation.blade.php      # Page Réclamations
```

## Installation

### 1. Copier les fichiers dans votre projet Laravel

```bash
# Copier les vues
cp blade/*.blade.php resources/views/
cp blade/partials/*.blade.php resources/views/partials/

# Créer le dossier pour le logo
mkdir -p public/images
# Placer votre logo dans public/images/logo.png
```

### 2. Créer les routes (routes/web.php)

```php
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;

Route::get('/', [DashboardController::class, 'dashboard'])->name('dashboard');
Route::get('/employe', [DashboardController::class, 'employe'])->name('employe');
Route::get('/statistiques', [DashboardController::class, 'statistiques'])->name('statistiques');
Route::get('/reclamation', [DashboardController::class, 'reclamation'])->name('reclamation');
```

### 3. Créer le contrôleur

```bash
php artisan make:controller DashboardController
```

**app/Http/Controllers/DashboardController.php:**

```php
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function dashboard()
    {
        $stats = [
            'commandes_actives' => 12,
            'revenus_jour' => '485k',
            'clients_actifs' => 28,
            'performance' => '94%'
        ];

        $orders = [
            ['name' => 'Eru', 'description' => 'Marie Dubois . Sur place', 'price' => '1000F', 'color' => 'bg-[#F4E04D]'],
            ['name' => 'Poulet pané', 'description' => 'Paul Martin . Livraison', 'price' => '2500F', 'color' => 'bg-[#6B7FFF]'],
            ['name' => 'Bissap', 'description' => 'Sophie Laurent . Sur place', 'price' => '500F', 'color' => 'bg-[#4ADE80]'],
            ['name' => 'Gateau mabré', 'description' => 'Andy Biga . Livraison', 'price' => '1000F', 'color' => 'bg-black'],
        ];

        $employees = [
            ['name' => 'Marie mbida', 'role' => 'Serveuse', 'status' => 'En ligne'],
            ['name' => 'Jean Kouam', 'role' => 'Cuisinier', 'status' => 'En ligne'],
            ['name' => 'Paul Nkomo', 'role' => 'Livreur', 'status' => 'En livraison'],
            ['name' => 'Alice Mbella', 'role' => 'Caissiere', 'status' => 'En pause'],
        ];

        return view('dashboard', compact('stats', 'orders', 'employees'));
    }

    public function employe()
    {
        $stats = [
            'total_employes' => 12,
            'en_service' => 8,
            'en_pause' => 2,
            'absents' => 2
        ];

        $employees = [
            [
                'name' => 'Marie mbida',
                'email' => 'marie.mbida@zeducspace.com',
                'role' => 'Serveuse',
                'roleColor' => 'text-[#8B5CF6]',
                'status' => 'En ligne',
                'statusColor' => 'text-green-500',
                'lastConnection' => 'Il y a 5 minutes',
                'performance' => '92%',
            ],
            [
                'name' => 'Jean Kouam',
                'email' => 'jean.kouam@zeducspace.com',
                'role' => 'Cuisinier',
                'roleColor' => 'text-red-500',
                'status' => 'En ligne',
                'statusColor' => 'text-green-500',
                'lastConnection' => 'Il y a 12 minutes',
                'performance' => '88%',
            ],
            [
                'name' => 'Paul Nkomo',
                'email' => 'paul.nkomo@zeducspace.com',
                'role' => 'Livreur',
                'roleColor' => 'text-purple-500',
                'status' => 'En livraison',
                'statusColor' => 'text-blue-500',
                'lastConnection' => 'Il y a 30 minutes',
                'performance' => '95%',
            ],
            [
                'name' => 'Alice Mbella',
                'email' => 'alice.mbella@zeducspace.com',
                'role' => 'Caissiere',
                'roleColor' => 'text-green-500',
                'status' => 'En pause',
                'statusColor' => 'text-gray-500',
                'lastConnection' => 'Il y a 2 heures',
                'performance' => '85%',
            ],
        ];

        return view('employe', compact('stats', 'employees'));
    }

    public function statistiques()
    {
        $performanceData = [
            [
                'period' => 'Cette Semaine',
                'commandes' => 254,
                'revenus' => '2,850,000 CFA',
                'clients' => 87,
                'panierMoyen' => '6,580 CFA',
                'evolution' => '+92%',
                'evolutionColor' => 'text-green-500',
            ],
            [
                'period' => 'Semaine Précédente',
                'commandes' => 262,
                'revenus' => '2,940,000 CFA',
                'clients' => 95,
                'panierMoyen' => '6,580 CFA',
                'evolution' => '+8%',
                'evolutionColor' => 'text-green-500',
            ],
            [
                'period' => 'Ce mois',
                'commandes' => 1247,
                'revenus' => '10,200,000 CFA',
                'clients' => 342,
                'panierMoyen' => '8,080 CFA',
                'evolution' => '+15%',
                'evolutionColor' => 'text-green-500',
            ],
            [
                'period' => 'Mois précédent',
                'commandes' => 1854,
                'revenus' => '10,500,000 CFA',
                'clients' => 398,
                'panierMoyen' => '5,980 CFA',
                'evolution' => '+3%',
                'evolutionColor' => 'text-green-500',
            ],
        ];

        return view('statistiques', compact('performanceData'));
    }

    public function reclamation()
    {
        $reclamations = [
            [
                'id' => 'REC004',
                'title' => 'Réclamation *REC004',
                'customer' => 'Commande *1265 - Thomas M.',
                'date' => 'Il y a 8 minutes',
                'status' => 'Validation Requise',
                'statusBadge' => 'bg-[#F4E04D]',
                'iconBg' => 'bg-[#F4E04D]',
                'icon' => '⚠️',
                'clientComplaint' => [
                    'action' => 'Refus du produit',
                    'text' => '"Le platet était trop salée et la viande(poulet) était extremement dure Je serais trop déçu de la qualité"',
                    'author' => 'Thomas M., 14h',
                ],
                'employeeResponse' => [
                    'action' => 'Autre reponse',
                    'text' => '"Nous vous envoyons rapidement pour cette expérience. Je propose un remboursement de la moitié non affectée et une reduction de 15% sur la prochaine commande"',
                    'author' => 'Repondu Le 5 Novembre',
                ],
                'badges' => [
                    ['text' => 'ANNULATION PROPOSÉE', 'color' => 'bg-[#4ADE80] text-white'],
                    ['text' => 'PARTIELLE', 'color' => 'bg-[#EF4444] text-white'],
                    ['text' => 'BON DE 15%', 'color' => 'bg-[#F4E04D]'],
                    ['text' => 'VALIDATION REQUISE', 'color' => 'bg-gray-300'],
                ],
            ],
            [
                'id' => 'REC003',
                'title' => 'Réclamation *REC003',
                'customer' => 'Commande *1048 - Sophie L.',
                'date' => 'Il y a 2 heures',
                'status' => 'Traitement Employé',
                'statusBadge' => 'bg-[#6B7FFF]',
                'iconBg' => 'bg-[#6B7FFF]',
                'icon' => '👤',
                'clientComplaint' => [
                    'action' => 'Annulation de la Commande',
                    'text' => '"Vos commande n\'ont pattaïni pour 19:40 et il est maintenant 20H.Nous n\'en avons plus besoin."',
                    'author' => 'Sophie L., 11h',
                ],
                'employeeResponse' => [
                    'action' => 'Action proposée',
                    'text' => '"Nous vous excusons pour ce retard, je travaille en accuse de cafés Livraison avec temps limité, gratuit"',
                    'author' => 'Repondu Le 2 Fevrier',
                ],
                'badges' => [
                    ['text' => 'PRIX DÉLESTÉE', 'color' => 'bg-gray-300'],
                ],
            ],
        ];

        return view('reclamation', compact('reclamations'));
    }
}
```

## Utilisation

1. Démarrez votre serveur Laravel:
   ```bash
   php artisan serve
   ```

2. Accédez aux pages:
   - Dashboard: http://localhost:8000/
   - Employés: http://localhost:8000/employe
   - Statistiques: http://localhost:8000/statistiques
   - Réclamations: http://localhost:8000/reclamation

## Notes importantes

- Les graphiques utilisent Chart.js (chargé via CDN)
- Les icônes SVG sont directement intégrées dans le HTML
- Tailwind CSS est chargé via CDN (pour production, utilisez Laravel Mix/Vite)
- Remplacez `{{ asset('images/logo.png') }}` par le chemin de votre logo

## Personnalisation

Pour connecter à votre base de données, modifiez les méthodes du contrôleur pour récupérer les données depuis vos modèles au lieu des tableaux statiques.
