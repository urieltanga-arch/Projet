@extends('layout')

@section('title', 'Gestion des Employés - Zebus Space')

@section('content')
<div class="max-w-[1400px] mx-auto px-8 py-8">
    <div class="mb-8 flex items-center justify-between">
        <div>
            <h1 class="text-4xl mb-2">Gestion des Employés</h1>
            <p class="text-gray-600">Administration de l'équipe</p>
        </div>
        <button class="bg-[#D4AF37] text-black px-6 py-3 rounded-full hover:bg-[#C4A037] transition-colors">
            + Ajouter Employé
        </button>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-4 gap-6 mb-8">
        <div class="bg-[#F4E4A6] rounded-2xl p-6">
            <svg class="w-10 h-10 mb-4 text-[#6B7FFF]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
            <div class="text-4xl mb-2">{{ $stats['total_employes'] ?? 12 }}</div>
            <div class="text-sm text-gray-600 mb-1">Total</div>
            <div>Employés Actifs</div>
        </div>
        <div class="bg-[#F4E4A6] rounded-2xl p-6">
            <svg class="w-10 h-10 mb-4 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
            <div class="text-4xl mb-2">{{ $stats['en_service'] ?? 8 }}</div>
            <div class="text-sm text-gray-600 mb-1">En service</div>
            <div>present Aujourd'hui</div>
        </div>
        <div class="bg-[#F4E4A6] rounded-2xl p-6">
            <svg class="w-10 h-10 mb-4 text-[#F4E04D]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/>
            </svg>
            <div class="text-4xl mb-2">{{ $stats['en_pause'] ?? 2 }}</div>
            <div class="text-sm text-gray-600 mb-1">Connectés</div>
            <div>En pause</div>
        </div>
        <div class="bg-[#F4E4A6] rounded-2xl p-6">
            <svg class="w-10 h-10 mb-4 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
            <div class="text-4xl mb-2">{{ $stats['absents'] ?? 2 }}</div>
            <div class="text-sm text-gray-600 mb-1">Absents</div>
            <div>Gestion Equipe</div>
        </div>
    </div>

    <!-- Table des employés -->
    <div class="bg-white rounded-2xl overflow-hidden">
        <!-- Table Header -->
        <div class="bg-[#D4AF37] px-6 py-4 grid grid-cols-[2fr,1fr,1fr,1.5fr,1fr,1fr] gap-4">
            <div class="text-justify">Employés</div>
            <div>Role</div>
            <div>Statut</div>
            <div>Dernière Connexion</div>
            <div>Performance</div>
            <div>Actions</div>
        </div>

        <!-- Table Body -->
        <div class="divide-y divide-gray-100">
            @foreach($employees ?? [] as $employee)
            <div class="px-6 py-5 grid grid-cols-[2fr,1fr,1fr,1.5fr,1fr,1fr] gap-4 items-center hover:bg-gray-50 transition-colors">
                <!-- Employee Info -->
                <div class="flex items-center gap-3">
                    <div class="w-12 h-12 bg-[#1E1E3F] rounded-full flex items-center justify-center text-white text-xl flex-shrink-0">
                        👤
                    </div>
                    <div>
                        <div>{{ $employee['name'] }}</div>
                        <div class="text-sm text-gray-500">{{ $employee['email'] }}</div>
                    </div>
                </div>

                <!-- Role -->
                <div class="{{ $employee['roleColor'] }}">
                    {{ $employee['role'] }}
                </div>

                <!-- Status -->
                <div class="flex items-center gap-2">
                    <div class="w-2 h-2 rounded-full 
                        @if($employee['status'] == 'En ligne') bg-green-500
                        @elseif($employee['status'] == 'En livraison') bg-blue-500
                        @else bg-gray-400
                        @endif">
                    </div>
                    <span class="{{ $employee['statusColor'] }}">{{ $employee['status'] }}</span>
                </div>

                <!-- Last Connection -->
                <div class="text-gray-600">
                    {{ $employee['lastConnection'] }}
                </div>

                <!-- Performance -->
                <div>
                    {{ $employee['performance'] }}
                </div>

                <!-- Actions -->
                <div class="flex items-center gap-2">
                    <button class="p-2 hover:bg-blue-50 rounded transition-colors">
                        <svg class="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
                        </svg>
                    </button>
                    <button class="p-2 hover:bg-orange-50 rounded transition-colors">
                        <svg class="w-5 h-5 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
                        </svg>
                    </button>
                    <button class="p-2 hover:bg-red-50 rounded transition-colors">
                        <svg class="w-5 h-5 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                        </svg>
                    </button>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>
@endsection
