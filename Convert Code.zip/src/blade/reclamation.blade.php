@extends('layout')

@section('title', 'Supervision des Réclamations - Zebus Space')

@section('content')
<div class="max-w-[1400px] mx-auto px-8 py-8">
    <div class="mb-8">
        <h1 class="text-4xl mb-2">Supervision des Réclamation</h1>
        <p class="text-gray-600">Contrôle et validation des réponses employés</p>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-5 gap-6 mb-8">
        <div class="bg-white rounded-xl p-6 border border-gray-200">
            <svg class="w-10 h-10 mb-4 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
            </svg>
            <div class="text-4xl mb-2">8</div>
            <div class="text-sm text-gray-600 mb-1">Total</div>
            <div>Réclamation Actives</div>
        </div>
        <div class="bg-white rounded-xl p-6 border border-gray-200">
            <svg class="w-10 h-10 mb-4 text-[#F4E04D]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
            <div class="text-4xl mb-2">3</div>
            <div class="text-sm text-gray-600 mb-1">En attente</div>
            <div>Validation Requise</div>
        </div>
        <div class="bg-white rounded-xl p-6 border border-gray-200">
            <svg class="w-10 h-10 mb-4 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
            </svg>
            <div class="text-4xl mb-2">5</div>
            <div class="text-sm text-gray-600 mb-1">Traitement</div>
            <div>Réponses Employés</div>
        </div>
        <div class="bg-white rounded-xl p-6 border border-gray-200">
            <svg class="w-10 h-10 mb-4 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
            <div class="text-4xl mb-2">5</div>
            <div class="text-sm text-gray-600 mb-1">en service</div>
            <div>Traitées</div>
        </div>
        <div class="bg-white rounded-xl p-6 border border-gray-200">
            <svg class="w-10 h-10 mb-4 text-[#4ADE80]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
            <div class="text-4xl mb-2">15</div>
            <div class="text-sm text-gray-600 mb-1">Ce mois</div>
            <div>Résolue</div>
        </div>
    </div>

    <!-- Réclamations List -->
    <div class="space-y-6">
        @foreach($reclamations ?? [] as $reclamation)
        <div class="bg-white rounded-2xl p-6 border border-gray-200">
            <!-- Header -->
            <div class="flex items-start justify-between mb-6">
                <div class="flex items-center gap-4">
                    <div class="w-12 h-12 {{ $reclamation['iconBg'] }} rounded-full flex items-center justify-center text-2xl">
                        {{ $reclamation['icon'] }}
                    </div>
                    <div>
                        <h3 class="text-xl mb-1">{{ $reclamation['title'] }}</h3>
                        <p class="text-sm text-gray-600">
                            {{ $reclamation['customer'] }} . {{ $reclamation['date'] }}
                        </p>
                    </div>
                </div>
                <div class="{{ $reclamation['statusBadge'] }} px-6 py-2 rounded-full">
                    {{ $reclamation['status'] }}
                </div>
            </div>

            <div class="grid grid-cols-2 gap-6 mb-6">
                <!-- Réclamation Client -->
                <div>
                    <h4 class="mb-3">Réclamation Client</h4>
                    <div class="bg-[rgb(244,224,77)] bg-opacity-20 rounded-xl p-4">
                        <div class="mb-2">{{ $reclamation['clientComplaint']['action'] }}</div>
                        <p class="text-sm mb-2">{{ $reclamation['clientComplaint']['text'] }}</p>
                        <p class="text-xs text-gray-600">{{ $reclamation['clientComplaint']['author'] }}</p>
                    </div>
                </div>

                <!-- Réponse Employé -->
                <div>
                    <h4 class="mb-3">Réponse Employé</h4>
                    <div class="bg-[rgba(244,224,77,0.36)] bg-opacity-20 rounded-xl p-4">
                        <div class="mb-2">{{ $reclamation['employeeResponse']['action'] }}</div>
                        <p class="text-sm mb-2">{{ $reclamation['employeeResponse']['text'] }}</p>
                        <p class="text-xs text-gray-600">{{ $reclamation['employeeResponse']['author'] }}</p>
                    </div>
                </div>
            </div>

            <!-- Badges -->
            <div class="flex gap-2">
                @foreach($reclamation['badges'] as $badge)
                <span class="{{ $badge['color'] }} px-4 py-2 rounded-lg text-sm">
                    {{ $badge['text'] }}
                </span>
                @endforeach
            </div>
        </div>
        @endforeach
    </div>
</div>
@endsection
