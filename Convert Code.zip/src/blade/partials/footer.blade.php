<footer class="bg-black text-white py-6">
    <div class="max-w-[1400px] mx-auto px-8 flex items-center justify-between">
        <div class="flex items-center gap-4">
            <span class="text-sm">Order.cm ©Copyright 2025, All Rights Reserved.</span>
        </div>
        
        <img src="{{ asset('images/logo.png') }}" alt="Zebus Space" class="h-12" />
        
        <div class="flex items-center gap-6 text-sm">
            <a href="#" class="hover:text-[#D4AF37] transition-colors">Privacy Policy</a>
            <a href="#" class="hover:text-[#D4AF37] transition-colors">Terms</a>
            <a href="#" class="hover:text-[#D4AF37] transition-colors">Pricing</a>
            <a href="#" class="hover:text-[#D4AF37] transition-colors">Do not share your personal information</a>
        </div>
    </div>
</footer>
