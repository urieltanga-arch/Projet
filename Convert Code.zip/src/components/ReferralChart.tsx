import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const data = [
  { week: 'Sem 1', nouveauxFilleuls: 12, commissionsPayees: 8, commissionsAttente: 4 },
  { week: 'Sem 2', nouveauxFilleuls: 18, commissionsPayees: 12, commissionsAttente: 6 },
  { week: 'Sem 3', nouveauxFilleuls: 25, commissionsPayees: 18, commissionsAttente: 7 },
  { week: 'Sem 4', nouveauxFilleuls: 30, commissionsPayees: 22, commissionsAttente: 8 },
  { week: 'Sem 5', nouveauxFilleuls: 35, commissionsPayees: 28, commissionsAttente: 7 },
  { week: 'Sem 6', nouveauxFilleuls: 40, commissionsPayees: 32, commissionsAttente: 8 },
  { week: 'Sem 7', nouveauxFilleuls: 42, commissionsPayees: 35, commissionsAttente: 7 },
  { week: 'Sem 8', nouveauxFilleuls: 45, commissionsPayees: 38, commissionsAttente: 7 },
];

export function ReferralChart() {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
        <XAxis dataKey="week" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line 
          type="monotone" 
          dataKey="nouveauxFilleuls" 
          stroke="#F4E04D" 
          strokeWidth={2} 
          name="Nouveaux Filleuls"
          dot={false}
        />
        <Line 
          type="monotone" 
          dataKey="commissionsPayees" 
          stroke="#000000" 
          strokeWidth={2} 
          name="Commissions Payées"
          dot={false}
        />
        <Line 
          type="monotone" 
          dataKey="commissionsAttente" 
          stroke="#6B7FFF" 
          strokeWidth={2} 
          name="Commissions d'Attente"
          dot={false}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
