import image_b99327ac68af126dfdf91acc1384722c8bd47c41 from 'figma:asset/b99327ac68af126dfdf91acc1384722c8bd47c41.png';
import { User } from 'lucide-react';
import logoImage from 'figma:asset/928a6da2c5dde5c00f6ddfb384edad16622471e5.png';

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: 'dashboard' | 'employe' | 'statistiques' | 'reclamation') => void;
}

export function Header({ currentPage, onNavigate }: HeaderProps) {
  return (
    <header className="bg-black text-white px-8 py-4">
      <div className="max-w-[1400px] mx-auto flex items-center justify-between">
        <div className="flex items-center gap-12">
          <img src={image_b99327ac68af126dfdf91acc1384722c8bd47c41} alt="Zebus Space" className="h-12" />
          <nav className="flex gap-8">
            <button
              onClick={() => onNavigate('dashboard')}
              className={`px-4 py-2 transition-colors ${
                currentPage === 'dashboard'
                  ? 'text-[#D4AF37]'
                  : 'text-white hover:text-[#D4AF37]'
              }`}
            >
              Dashboard
            </button>
            <button
              onClick={() => onNavigate('employe')}
              className={`px-4 py-2 transition-colors ${
                currentPage === 'employe'
                  ? 'text-[#D4AF37]'
                  : 'text-white hover:text-[#D4AF37]'
              }`}
            >
              Employé
            </button>
            <button
              onClick={() => onNavigate('statistiques')}
              className={`px-4 py-2 transition-colors ${
                currentPage === 'statistiques'
                  ? 'text-[#D4AF37]'
                  : 'text-white hover:text-[#D4AF37]'
              }`}
            >
              Statistiques
            </button>
            <button
              onClick={() => onNavigate('reclamation')}
              className={`px-4 py-2 transition-colors ${
                currentPage === 'reclamation'
                  ? 'text-[#D4AF37]'
                  : 'text-white hover:text-[#D4AF37]'
              }`}
            >
              Réclamation
            </button>
          </nav>
        </div>
        <div className="w-8 h-8 rounded-full border-2 border-[#D4AF37] flex items-center justify-center">
          <User className="w-5 h-5 text-[#D4AF37]" />
        </div>
      </div>
    </header>
  );
}
