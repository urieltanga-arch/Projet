import { UserCheck, CheckCircle, Coffee, XCircle, MessageSquare, BarChart3, Trash2 } from 'lucide-react';

const employees = [
  {
    name: 'Marie mbida',
    email: 'marie.mbida@zeducspace.com',
    role: 'Serveuse',
    roleColor: 'text-[#8B5CF6]',
    status: 'En ligne',
    statusColor: 'text-green-500',
    lastConnection: 'Il y a 5 minutes',
    performance: '92%',
  },
  {
    name: 'Jean Kouam',
    email: 'jean.kouam@zeducspace.com',
    role: 'Cuisinier',
    roleColor: 'text-red-500',
    status: 'En ligne',
    statusColor: 'text-green-500',
    lastConnection: 'Il y a 12 minutes',
    performance: '88%',
  },
  {
    name: 'Paul Nkomo',
    email: 'paul.nkomo@zeducspace.com',
    role: 'Livreur',
    roleColor: 'text-purple-500',
    status: 'En livraison',
    statusColor: 'text-blue-500',
    lastConnection: 'Il y a 30 minutes',
    performance: '95%',
  },
  {
    name: 'Alice Mbella',
    email: 'alice.mbella@zeducspace.com',
    role: 'Caissiere',
    roleColor: 'text-green-500',
    status: 'En pause',
    statusColor: 'text-gray-500',
    lastConnection: 'Il y a 2 heures',
    performance: '85%',
  },
];

export function EmployeesPage() {
  return (
    <div className="max-w-[1400px] mx-auto px-8 py-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-4xl mb-2">Gestion des Employés</h1>
          <p className="text-gray-600">Administration de l'équipe</p>
        </div>
        <button className="bg-[#D4AF37] text-black px-6 py-3 rounded-full hover:bg-[#C4A037] transition-colors">
          + Ajouter Employé
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="bg-[#F4E4A6] rounded-2xl p-6">
          <UserCheck className="w-10 h-10 mb-4 text-[#6B7FFF]" />
          <div className="text-4xl mb-2">12</div>
          <div className="text-sm text-gray-600 mb-1">Total</div>
          <div>Employés Actifs</div>
        </div>
        <div className="bg-[#F4E4A6] rounded-2xl p-6">
          <CheckCircle className="w-10 h-10 mb-4 text-green-500" />
          <div className="text-4xl mb-2">8</div>
          <div className="text-sm text-gray-600 mb-1">En service</div>
          <div>present Aujourd'hui</div>
        </div>
        <div className="bg-[#F4E4A6] rounded-2xl p-6">
          <Coffee className="w-10 h-10 mb-4 text-[#F4E04D]" />
          <div className="text-4xl mb-2">2</div>
          <div className="text-sm text-gray-600 mb-1">Connectés</div>
          <div>En pause</div>
        </div>
        <div className="bg-[#F4E4A6] rounded-2xl p-6">
          <XCircle className="w-10 h-10 mb-4 text-red-500" />
          <div className="text-4xl mb-2">2</div>
          <div className="text-sm text-gray-600 mb-1">Absents</div>
          <div>Gestion Equipe</div>
        </div>
      </div>

      {/* Table des employés */}
      <div className="bg-white rounded-2xl overflow-hidden">
        {/* Table Header */}
        <div className="bg-[#D4AF37] px-6 py-4 grid grid-cols-[2fr,1fr,1fr,1.5fr,1fr,1fr] gap-4">
          <div className="text-justify">Employés</div>
          <div>Role</div>
          <div>Statut</div>
          <div>Dernière Connexion</div>
          <div>Performance</div>
          <div>Actions</div>
        </div>

        {/* Table Body */}
        <div className="divide-y divide-gray-100">
          {employees.map((employee, index) => (
            <div key={index} className="px-6 py-5 grid grid-cols-[2fr,1fr,1fr,1.5fr,1fr,1fr] gap-4 items-center hover:bg-gray-50 transition-colors">
              {/* Employee Info */}
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-[#1E1E3F] rounded-full flex items-center justify-center text-white text-xl flex-shrink-0">
                  👤
                </div>
                <div>
                  <div>{employee.name}</div>
                  <div className="text-sm text-gray-500">{employee.email}</div>
                </div>
              </div>

              {/* Role */}
              <div className={employee.roleColor}>
                {employee.role}
              </div>

              {/* Status */}
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${
                  employee.status === 'En ligne' ? 'bg-green-500' :
                  employee.status === 'En livraison' ? 'bg-blue-500' :
                  'bg-gray-400'
                }`}></div>
                <span className={employee.statusColor}>{employee.status}</span>
              </div>

              {/* Last Connection */}
              <div className="text-gray-600">
                {employee.lastConnection}
              </div>

              {/* Performance */}
              <div>
                {employee.performance}
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2">
                <button className="p-2 hover:bg-blue-50 rounded transition-colors">
                  <MessageSquare className="w-5 h-5 text-blue-500" />
                </button>
                <button className="p-2 hover:bg-orange-50 rounded transition-colors">
                  <BarChart3 className="w-5 h-5 text-orange-500" />
                </button>
                <button className="p-2 hover:bg-red-50 rounded transition-colors">
                  <Trash2 className="w-5 h-5 text-red-500" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
