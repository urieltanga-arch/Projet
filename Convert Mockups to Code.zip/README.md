
  # Convert Mockups to Code

  This is a code bundle for Convert Mockups to Code. The original project is available at https://www.figma.com/design/5bgiRW2vfmUT9ykZPY3FCK/Convert-Mockups-to-Code.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  