import { AlertTriangle, AlertCircle, Users, CheckCircle2, CheckCircle } from 'lucide-react';

const reclamations = [
  {
    id: 'REC004',
    title: 'Réclamation *REC004',
    customer: 'Commande *1265 - Thomas M.',
    date: 'Il y a 8 minutes',
    status: 'Validation Requise',
    statusBadge: 'bg-[#F4E04D]',
    iconBg: 'bg-[#F4E04D]',
    icon: '⚠️',
    clientComplaint: {
      action: 'Refus du produit',
      text: '"Le platet était trop salée et la viande(poulet) était extremement dure Je serais trop déçu de la qualité"',
      author: 'Thomas M., 14h',
    },
    employeeResponse: {
      action: 'Autre reponse',
      text: '"Nous vous envoyons rapidement pour cette expérience. Je propose un remboursement de la moitié non affectée et une reduction de 15% sur la prochaine commande"',
      author: 'Repondu Le 5 Novembre',
    },
    badges: [
      { text: 'ANNULATION PROPOSÉE', color: 'bg-[#4ADE80] text-white' },
      { text: 'PARTIELLE', color: 'bg-[#EF4444] text-white' },
      { text: 'BON DE 15%', color: 'bg-[#F4E04D]' },
      { text: 'VALIDATION REQUISE', color: 'bg-gray-300' },
    ],
  },
  {
    id: 'REC003',
    title: 'Réclamation *REC003',
    customer: 'Commande *1048 - Sophie L.',
    date: 'Il y a 2 heures',
    status: 'Traitement Employé',
    statusBadge: 'bg-[#6B7FFF]',
    iconBg: 'bg-[#6B7FFF]',
    icon: '👤',
    clientComplaint: {
      action: 'Annulation de la Commande',
      text: '"Vos commande n\'ont pattaïni pour 19:40 et il est maintenant 20H.Nous n\'en avons plus besoin."',
      author: 'Sophie L., 11h',
    },
    employeeResponse: {
      action: 'Action proposée',
      text: '"Nous vous excusons pour ce retard, je travaille en accuse de cafés Livraison avec temps limité, gratuit"',
      author: 'Repondu Le 2 Fevrier',
    },
    badges: [
      { text: 'PRIX DÉLESTÉE', color: 'bg-gray-300' },
    ],
  },
  {
    id: 'REC002',
    title: 'Réclamation *REC002',
    customer: 'Commande *1238 - Paul N.',
    date: 'Il y a 1 jour',
    status: 'Approuvé',
    statusBadge: 'bg-[#4ADE80]',
    iconBg: 'bg-[#4ADE80]',
    icon: '✓',
    clientComplaint: {
      action: 'Commande incomplète',
      text: '"J\'ai reçu à partenie de ma commande car toutes les radios de 1an d\'amandes."',
      author: 'Paul N., 9h',
    },
    employeeResponse: {
      action: 'Action proposée',
      text: '"Nous vous excusons pour cet oubli. Renvoyement en la boisson de réduction de 15% sur le prochain commande"',
      author: 'Repondu Le 10 Janvier',
    },
    badges: [
      { text: 'COMMANDE APPROUVÉE', color: 'bg-gray-300' },
    ],
  },
];

export function ReclamationPage() {
  return (
    <div className="max-w-[1400px] mx-auto px-8 py-8">
      <div className="mb-8">
        <h1 className="text-4xl mb-2">Supervision des Réclamation</h1>
        <p className="text-gray-600">Contrôle et validation des réponses employés</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-5 gap-6 mb-8">
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <AlertTriangle className="w-10 h-10 mb-4 text-red-500" />
          <div className="text-4xl mb-2">8</div>
          <div className="text-sm text-gray-600 mb-1">Total</div>
          <div>Réclamation Actives</div>
        </div>
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <AlertCircle className="w-10 h-10 mb-4 text-[#F4E04D]" />
          <div className="text-4xl mb-2">3</div>
          <div className="text-sm text-gray-600 mb-1">En attente</div>
          <div>Validation Requise</div>
        </div>
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <Users className="w-10 h-10 mb-4 text-blue-500" />
          <div className="text-4xl mb-2">5</div>
          <div className="text-sm text-gray-600 mb-1">Traitement</div>
          <div>Réponses Employés</div>
        </div>
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <CheckCircle2 className="w-10 h-10 mb-4 text-blue-500" />
          <div className="text-4xl mb-2">5</div>
          <div className="text-sm text-gray-600 mb-1">en service</div>
          <div>Traitées</div>
        </div>
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <CheckCircle className="w-10 h-10 mb-4 text-[#4ADE80]" />
          <div className="text-4xl mb-2">15</div>
          <div className="text-sm text-gray-600 mb-1">Ce mois</div>
          <div>Résolue</div>
        </div>
      </div>

      {/* Réclamations List */}
      <div className="space-y-6">
        {reclamations.map((reclamation, index) => (
          <div key={index} className="bg-white rounded-2xl p-6 border border-gray-200">
            {/* Header */}
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 ${reclamation.iconBg} rounded-full flex items-center justify-center text-2xl`}>
                  {reclamation.icon}
                </div>
                <div>
                  <h3 className="text-xl mb-1">{reclamation.title}</h3>
                  <p className="text-sm text-gray-600">
                    {reclamation.customer} . {reclamation.date}
                  </p>
                </div>
              </div>
              <div className={`${reclamation.statusBadge} px-6 py-2 rounded-full`}>
                {reclamation.status}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6 mb-6">
              {/* Réclamation Client */}
              <div>
                <h4 className="mb-3">Réclamation Client</h4>
                <div className="bg-[rgb(244,224,77)] bg-opacity-20 rounded-xl p-4">
                  <div className="mb-2">{reclamation.clientComplaint.action}</div>
                  <p className="text-sm mb-2">{reclamation.clientComplaint.text}</p>
                  <p className="text-xs text-gray-600">{reclamation.clientComplaint.author}</p>
                </div>
              </div>

              {/* Réponse Employé */}
              <div>
                <h4 className="mb-3">Réponse Employé</h4>
                <div className="bg-[rgba(244,224,77,0.36)] bg-opacity-20 rounded-xl p-4">
                  <div className="mb-2">{reclamation.employeeResponse.action}</div>
                  <p className="text-sm mb-2">{reclamation.employeeResponse.text}</p>
                  <p className="text-xs text-gray-600">{reclamation.employeeResponse.author}</p>
                </div>
              </div>
            </div>

            {/* Badges */}
            <div className="flex gap-2">
              {reclamation.badges.map((badge, badgeIndex) => (
                <span 
                  key={badgeIndex} 
                  className={`${badge.color} px-4 py-2 rounded-lg text-sm`}
                >
                  {badge.text}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
