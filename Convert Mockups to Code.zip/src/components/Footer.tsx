import image_b99327ac68af126dfdf91acc1384722c8bd47c41 from 'figma:asset/b99327ac68af126dfdf91acc1384722c8bd47c41.png';
import logoImage from 'figma:asset/928a6da2c5dde5c00f6ddfb384edad16622471e5.png';

export function Footer() {
  return (
    <footer className="bg-black text-white py-6">
      <div className="max-w-[1400px] mx-auto px-8 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <span className="text-sm">Order.cm ©Copyright 2025, All Rights Reserved.</span>
        </div>
        <img src={image_b99327ac68af126dfdf91acc1384722c8bd47c41} alt="Zebus Space" className="h-12" />
        <div className="flex items-center gap-6 text-sm">
          <a href="#" className="hover:text-[#D4AF37] transition-colors">Privacy Policy</a>
          <a href="#" className="hover:text-[#D4AF37] transition-colors">Terms</a>
          <a href="#" className="hover:text-[#D4AF37] transition-colors">Pricing</a>
          <a href="#" className="hover:text-[#D4AF37] transition-colors">Do not share your personal information</a>
        </div>
      </div>
    </footer>
  );
}
