import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const data = [
  { time: '8h', commandes: 20, revenus: 15 },
  { time: '9h', commandes: 40, revenus: 25 },
  { time: '10h', commandes: 60, revenus: 35 },
  { time: '11h', commandes: 120, revenus: 45 },
  { time: '12h', commandes: 180, revenus: 55 },
  { time: '13h', commandes: 160, revenus: 52 },
  { time: '14h', commandes: 100, revenus: 48 },
  { time: '15h', commandes: 80, revenus: 42 },
  { time: '16h', commandes: 90, revenus: 45 },
  { time: '17h', commandes: 140, revenus: 50 },
  { time: '18h', commandes: 180, revenus: 54 },
  { time: '19h', commandes: 160, revenus: 52 },
  { time: '20h', commandes: 120, revenus: 48 },
];

export function PerformanceChart() {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
        <XAxis dataKey="time" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line 
          type="monotone" 
          dataKey="commandes" 
          stroke="#000000" 
          strokeWidth={2} 
          name="Commandes"
          dot={false}
        />
        <Line 
          type="monotone" 
          dataKey="revenus" 
          stroke="#D4AF37" 
          strokeWidth={2} 
          name="Revenus (x1000 FCFA)"
          dot={false}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
