import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from 'recharts';

const data = [
  { name: 'Plats Principaux', value: 45, color: '#F4E04D' },
  { name: 'Grillades', value: 25, color: '#D4AF37' },
  { name: 'Boissons', value: 20, color: '#000000' },
  { name: 'Desserts', value: 10, color: '#F4E04D' },
];

const COLORS = ['#F4E04D', '#D4AF37', '#000000', '#F4E04D'];

export function CategoryChart() {
  return (
    <div className="flex items-center justify-center">
      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={100}
            paddingAngle={5}
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Legend 
            verticalAlign="bottom" 
            height={36}
            formatter={(value, entry: any) => (
              <span className="text-sm">
                {value} - {entry.payload.value}%
              </span>
            )}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
