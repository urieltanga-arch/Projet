import { ShoppingCart, Wallet, Users, TrendingUp, AlertTriangle } from 'lucide-react';
import { PerformanceChart } from './PerformanceChart';

const employees = [
  { name: 'Marie mbida', role: 'Serveuse', status: 'En ligne', avatar: '👤' },
  { name: 'Jean Kouam', role: 'Cuisinier', status: 'En ligne', avatar: '👤' },
  { name: 'Paul Nkomo', role: 'Livreur', status: 'En livraison', avatar: '👤' },
  { name: 'Alice Mbella', role: 'Caissiere', status: 'En pause', avatar: '👤' },
];

const orders = [
  { name: 'Eru', description: 'Marie Dubois . Sur place', price: '1000F', color: 'bg-[#F4E04D]' },
  { name: 'Poulet pané', description: 'Paul Martin . Livraison', price: '2500F', color: 'bg-[#6B7FFF]' },
  { name: 'Bissap', description: 'Sophie Laurent . Sur place', price: '500F', color: 'bg-[#4ADE80]' },
  { name: 'Gateau mabré', description: 'Andy Biga . Livraison', price: '1000F', color: 'bg-black' },
];

export function DashboardPage() {
  return (
    <div className="max-w-[1400px] mx-auto px-8 py-8">
      <div className="mb-8">
        <h1 className="text-4xl mb-2">Dashboard Gérant</h1>
        <p className="text-gray-600">Vue d'ensemble en temp réel du restaurant</p>
      </div>

      {/* Alertes importantes */}
      <div className="bg-[#EE9A9A] rounded-2xl p-6 mb-8 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="bg-[#E57373] rounded-full p-4">
            <AlertTriangle className="w-8 h-8 text-white" />
          </div>
          <div>
            <h3 className="text-xl mb-1">Alertes importantes</h3>
            <p className="text-sm">3 réclamations urgentes en attente . Stock faible : Tiramisu</p>
          </div>
        </div>
        <button className="bg-white text-gray-800 px-6 py-2 rounded-full hover:bg-gray-100 transition-colors">
          Voir Détails
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="bg-[#D4AF37] rounded-2xl p-6 text-black">
          <ShoppingCart className="w-10 h-10 mb-4" />
          <div className="text-4xl mb-2">12</div>
          <div className="text-sm">En Cours</div>
          <div className="mt-2">Commandes Actives</div>
        </div>
        <div className="bg-black rounded-2xl p-6 text-white">
          <Wallet className="w-10 h-10 mb-4 text-[#D4AF37]" />
          <div className="text-4xl mb-2">485k</div>
          <div className="text-sm">FCFA</div>
          <div className="mt-2">Revenus du jour</div>
        </div>
        <div className="bg-white rounded-2xl p-6 border border-gray-200">
          <Users className="w-10 h-10 mb-4 text-[#6B7FFF]" />
          <div className="text-4xl mb-2">28</div>
          <div className="text-sm">Connectés</div>
          <div className="mt-2">Clients Actifs</div>
        </div>
        <div className="bg-white rounded-2xl p-6 border border-gray-200">
          <TrendingUp className="w-10 h-10 mb-4 text-gray-600" />
          <div className="text-4xl mb-2">94%</div>
          <div className="text-sm">Efficacité</div>
          <div className="mt-2">Performance Équipe</div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6 mb-8">
        {/* Commandes en Temps Réel */}
        <div className="bg-white rounded-2xl p-6">
          <h3 className="text-xl mb-6">Commandes en Temps Réel</h3>
          <div className="space-y-3">
            {orders.map((order, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-[rgba(242,242,10,0.13)] rounded-xl">
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 ${order.color} rounded-full`}></div>
                  <div>
                    <div>{order.name}</div>
                    <div className="text-sm text-gray-500">{order.description}</div>
                  </div>
                </div>
                <div>
                  <div>{order.price}</div>
                  <div className="text-xs text-gray-500">en preparation</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Performances Journaliere */}
        <div className="bg-white rounded-2xl p-6">
          <h3 className="text-xl mb-6">Performances Journaliere</h3>
          <PerformanceChart />
        </div>
      </div>

      {/* Équipe en Service */}
      <div>
        <h3 className="text-xl mb-6">Équipe en Service</h3>
        <div className="grid grid-cols-4 gap-6">
          {employees.map((employee, index) => (
            <div key={index} className="bg-white rounded-xl p-6 border border-gray-200">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 bg-[#1E1E3F] rounded-full flex items-center justify-center text-white text-xl">
                  👤
                </div>
                <div>
                  <div>{employee.name}</div>
                  <div className="text-sm text-gray-500">{employee.role}</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm text-gray-600">{employee.status}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
