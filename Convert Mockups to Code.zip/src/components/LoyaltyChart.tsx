import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Points Gagnes', value: 100 },
  { name: 'Point utilises', value: 80 },
  { name: 'Cadeaux echanges', value: 35 },
  { name: 'Nouveaux membres', value: 60 },
];

const COLORS = ['#F4E04D', '#000000', '#EF4444', '#4ADE80'];

export function LoyaltyChart() {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={data}>
        <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        {data.map((entry, index) => (
          <Bar 
            key={index}
            dataKey="value" 
            fill={COLORS[index]} 
            radius={[8, 8, 0, 0]}
            maxBarSize={80}
          />
        ))}
      </BarChart>
    </ResponsiveContainer>
  );
}
