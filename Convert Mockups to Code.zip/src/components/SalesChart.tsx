import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const data = [
  { month: 'Jan', ventes2025: 4, ventes2024: 2 },
  { month: 'Fev', ventes2025: 3, ventes2024: 3 },
  { month: 'Mar', ventes2025: 5, ventes2024: 4 },
  { month: 'Avr', ventes2025: 7, ventes2024: 5 },
  { month: 'Mai', ventes2025: 9, ventes2024: 6 },
  { month: 'Juin', ventes2025: 8, ventes2024: 7 },
  { month: 'Juil', ventes2025: 10, ventes2024: 8 },
  { month: 'Aou', ventes2025: 9, ventes2024: 7 },
  { month: 'Sep', ventes2025: 11, ventes2024: 8 },
  { month: 'Oct', ventes2025: 10, ventes2024: 9 },
  { month: 'Nov', ventes2025: 12, ventes2024: 10 },
  { month: 'Dec', ventes2025: 14, ventes2024: 11 },
];

export function SalesChart() {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
        <XAxis dataKey="month" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line 
          type="monotone" 
          dataKey="ventes2025" 
          stroke="#F4E04D" 
          strokeWidth={2} 
          name="Ventes 2025 (Millions FCFA)"
          dot={false}
        />
        <Line 
          type="monotone" 
          dataKey="ventes2024" 
          stroke="#000000" 
          strokeWidth={2} 
          name="Ventes 2024 (Millions FCFA)"
          dot={false}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
