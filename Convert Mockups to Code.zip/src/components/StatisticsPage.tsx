import { TrendingUp, ShoppingCart, Users, Star, Download } from 'lucide-react';
import { SalesChart } from './SalesChart';
import { CategoryChart } from './CategoryChart';
import { LoyaltyChart } from './LoyaltyChart';
import { ReferralChart } from './ReferralChart';

const performanceData = [
  {
    period: 'Cette Semaine',
    commandes: 254,
    revenus: '2,850,000 CFA',
    clients: 87,
    panierMoyen: '6,580 CFA',
    evolution: '+92%',
    evolutionColor: 'text-green-500',
  },
  {
    period: 'Semaine Précédente',
    commandes: 262,
    revenus: '2,940,000 CFA',
    clients: 95,
    panierMoyen: '6,580 CFA',
    evolution: '+8%',
    evolutionColor: 'text-green-500',
  },
  {
    period: 'Ce mois',
    commandes: 1247,
    revenus: '10,200,000 CFA',
    clients: 342,
    panierMoyen: '8,080 CFA',
    evolution: '+15%',
    evolutionColor: 'text-green-500',
  },
  {
    period: 'Mois précédent',
    commandes: 1854,
    revenus: '10,500,000 CFA',
    clients: 398,
    panierMoyen: '5,980 CFA',
    evolution: '+3%',
    evolutionColor: 'text-green-500',
  },
];

export function StatisticsPage() {
  return (
    <div className="max-w-[1400px] mx-auto px-8 py-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-4xl mb-2">Statistiques Avancées</h1>
          <p className="text-gray-600">Analyse complète des performances</p>
        </div>
        <div className="flex gap-3">
          <button className="bg-[#4ADE80] text-white px-6 py-3 rounded-lg hover:bg-[#3ABE70] transition-colors flex items-center gap-2">
            <Download className="w-5 h-5" />
            Exporter Excel
          </button>
          <button className="bg-[#EF4444] text-white px-6 py-3 rounded-lg hover:bg-[#DC2626] transition-colors flex items-center gap-2">
            <Download className="w-5 h-5" />
            Exporter PDF
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="bg-[#F4E04D] rounded-2xl p-6">
          <TrendingUp className="w-10 h-10 mb-4 text-black" />
          <div className="text-4xl mb-2">2.8M</div>
          <div className="text-sm text-gray-700">Chiffre d'Affaires</div>
        </div>
        <div className="bg-black rounded-2xl p-6 text-white">
          <ShoppingCart className="w-10 h-10 mb-4" />
          <div className="text-4xl mb-2">1,247</div>
          <div className="text-sm text-gray-300">Total Commandes</div>
        </div>
        <div className="bg-white rounded-2xl p-6 border border-gray-200">
          <Users className="w-10 h-10 mb-4 text-blue-500" />
          <div className="text-4xl mb-2">342</div>
          <div className="text-sm text-gray-600">Clients Actifs</div>
        </div>
        <div className="bg-[#F4E04D] rounded-2xl p-6">
          <Star className="w-10 h-10 mb-4 text-black" />
          <div className="text-4xl mb-2">4.7</div>
          <div className="text-sm text-gray-700">Satisfaction</div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6 mb-8">
        {/* Évolution des Ventes */}
        <div className="bg-white rounded-2xl p-6">
          <h3 className="text-xl mb-6">Évolution des Ventes</h3>
          <SalesChart />
        </div>

        {/* Répartition par Catégorie */}
        <div className="bg-white rounded-2xl p-6">
          <h3 className="text-xl mb-6">Répartition par Catégorie</h3>
          <CategoryChart />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6 mb-8">
        {/* Programme de Fidélité */}
        <div className="bg-white rounded-2xl p-6">
          <h3 className="text-xl mb-6">Programme de Fidélité</h3>
          <LoyaltyChart />
        </div>

        {/* Système de Parrainage */}
        <div className="bg-white rounded-2xl p-6">
          <h3 className="text-xl mb-6">Système de Parrainage</h3>
          <ReferralChart />
        </div>
      </div>

      {/* Performance Détaillée par Période */}
      <div className="bg-white rounded-2xl overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100">
          <h3 className="text-xl">Performance Détaillée par Période</h3>
        </div>
        
        {/* Table Header */}
        <div className="bg-[#F4E04D] px-6 py-4 grid grid-cols-6 gap-4">
          <div>Période</div>
          <div>Commandes</div>
          <div>Revenus</div>
          <div>Clients</div>
          <div>Panier moyen</div>
          <div>Evolution</div>
        </div>

        {/* Table Body */}
        <div className="divide-y divide-gray-100">
          {performanceData.map((row, index) => (
            <div key={index} className="px-6 py-5 grid grid-cols-6 gap-4 items-center hover:bg-gray-50 transition-colors">
              <div>{row.period}</div>
              <div>{row.commandes}</div>
              <div>{row.revenus}</div>
              <div>{row.clients}</div>
              <div>{row.panierMoyen}</div>
              <div className={row.evolutionColor}>{row.evolution}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
