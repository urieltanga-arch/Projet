import { useState } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { DashboardPage } from './components/DashboardPage';
import { EmployeesPage } from './components/EmployeesPage';
import { StatisticsPage } from './components/StatisticsPage';
import { ReclamationPage } from './components/ReclamationPage';

export default function App() {
  const [currentPage, setCurrentPage] = useState<'dashboard' | 'employe' | 'statistiques' | 'reclamation'>('dashboard');

  return (
    <div className="min-h-screen flex flex-col bg-[#F5F1E8]">
      <Header currentPage={currentPage} onNavigate={setCurrentPage} />
      <main className="flex-1">
        {currentPage === 'dashboard' && <DashboardPage />}
        {currentPage === 'employe' && <EmployeesPage />}
        {currentPage === 'statistiques' && <StatisticsPage />}
        {currentPage === 'reclamation' && <ReclamationPage />}
      </main>
      <Footer />
    </div>
  );
}
